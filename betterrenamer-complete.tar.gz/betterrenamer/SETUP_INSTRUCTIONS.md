# 🚀 Istruzioni di Setup - BetterRenamer

Segui questi passaggi per completare il setup dell'applicazione.

## Step 1: Prepara la cartella locale

Nel tuo terminale, vai nella cartella dove vuoi clonare il progetto:

```bash
cd ~/Projects  # (o dove preferisci)
git clone https://github.com/bettersushi/betterrenamer.git
cd betterrenamer
```

## Step 2: Copia tutti i file dal progetto

Avrai ricevuto una cartella `/home/claude/betterrenamer` con tutti i file.
Copia tutto il contenuto nella cartella locale:

```bash
# Se sei su macOS/Linux:
cp -r /home/claude/betterrenamer/* ~/Projects/betterrenamer/

# Se sei su Windows, usa:
# xcopy "percorso\sorgente\*" "percorso\destinazione" /E /I
```

Verifica che tutti questi file siano presenti:

```
betterrenamer/
├── src/
│   ├── pages/
│   │   ├── LoginPage.jsx
│   │   ├── LoginPage.css
│   │   ├── CallbackPage.jsx
│   │   ├── CallbackPage.css
│   │   ├── TwoFAPage.jsx
│   │   ├── TwoFAPage.css
│   │   ├── DashboardPage.jsx
│   │   └── DashboardPage.css
│   ├── App.jsx
│   ├── App.css
│   ├── main.jsx
│   ├── index.css
│   ├── auth.js
│   └── drive.js
├── netlify/
│   └── functions/
│       ├── exchange-token.js
│       ├── refresh-token.js
│       ├── generate-2fa.js
│       └── verify-2fa.js
├── index.html
├── package.json
├── vite.config.js
├── netlify.toml
├── .gitignore
├── .env.example
├── README.md
└── SETUP_INSTRUCTIONS.md
```

## Step 3: Installa le dipendenze

```bash
npm install
```

Questo installerà React, React Router, Vite e altre dipendenze necessarie.

## Step 4: Configura le variabili d'ambiente locali

Crea un file `.env.local` copiando da `.env.example`:

```bash
cp .env.example .env.local
```

Il contenuto sarà:

```
VITE_GOOGLE_CLIENT_ID=368176202917-k9bt652cgo9ihbbdm2f8i261j7dnj8sq.apps.googleusercontent.com
VITE_REDIRECT_URI=http://localhost:3000/callback
```

(Questi dati sono già corretti per il test locale)

## Step 5: Testa in locale

```bash
npm run dev
```

Apri il browser su `http://localhost:3000` e dovresti vedere la pagina di login.

**Nota**: In locale, il 2FA potrebbe non funzionare perfettamente perché usa la Google Chart API. Questo funzionerà correttamente su Netlify.

## Step 6: Configura Netlify con le variabili d'ambiente

Nel dashboard di Netlify (https://app.netlify.com):

1. Seleziona il progetto "betterrenamer"
2. Vai su **Site settings → Build & deploy → Environment**
3. Clicca **Add environment variables**
4. Aggiungi queste variabili:

| Key | Value |
|-----|-------|
| `GOOGLE_CLIENT_ID` | `368176202917-k9bt652cgo9ihbbdm2f8i261j7dnj8sq.apps.googleusercontent.com` |
| `GOOGLE_CLIENT_SECRET` | `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` |
| `REDIRECT_URI` | `https://courageous-stroopwafel-87ddee.netlify.app/callback` |

Nella sezione **Build environment variables**, aggiungi anche:

| Key | Value |
|-----|-------|
| `VITE_GOOGLE_CLIENT_ID` | `368176202917-k9bt652cgo9ihbbdm2f8i261j7dnj8sq.apps.googleusercontent.com` |
| `VITE_REDIRECT_URI` | `https://courageous-stroopwafel-87ddee.netlify.app/callback` |

## Step 7: Push su GitHub

```bash
# Aggiungi tutti i file
git add .

# Commit
git commit -m "Initial commit: BetterRenamer with OAuth 2.0 and 2FA"

# Push
git push -u origin main
```

Netlify dovrebbe iniziare il deploy automaticamente.

## Step 8: Verifica il deploy

Nel dashboard di Netlify:
1. Vai alla sezione "Deploys"
2. Dovrebbe vedere il deploy in corso
3. Aspetta che sia completato (solitamente 2-3 minuti)
4. Quando è pronto, clicca sul dominio: `https://courageous-stroopwafel-87ddee.netlify.app`

## Troubleshooting

### Errore: "VITE_GOOGLE_CLIENT_ID is not defined"
→ Le variabili d'ambiente non sono configurate correttamente in Netlify. Verifica che siano in "Build environment variables".

### Errore: "Token exchange failed"
→ Controlla che il `GOOGLE_CLIENT_SECRET` sia esatto nel dashboard Netlify.

### Errore: "OAuth redirect_uri mismatch"
→ Verifica che il `REDIRECT_URI` sia stato aggiunto correttamente nella Google Cloud Console.

### 2FA non funziona localmente
→ È normale. Funzionerà solo su Netlify. In locale puoi skippare il 2FA per testare.

---

**Quando tutto è pronto**, accedi a:

🔗 https://courageous-stroopwafel-87ddee.netlify.app

E il flusso sarà:
1. Clicca "Accedi con Google"
2. Autorizza l'accesso al tuo Drive
3. Configura il 2FA scansionando il QR code
4. Potrai usare BetterRenamer!

Domande? Chiedi pure! 🚀
